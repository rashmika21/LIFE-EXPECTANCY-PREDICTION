
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# In[2]:


dataset=pd.read_csv("Life Expectancy Data.csv")


# In[3]:


dataset


# In[4]:


dataset.drop(['Country'],axis=1,inplace=True)
dataset.drop(['Year'],axis=1,inplace=True)
dataset.drop(['Status'],axis=1,inplace=True)


# In[5]:


type(dataset)


# In[6]:


dataset.head()


# In[7]:


dataset.shape


# In[8]:


dataset.isnull().any()


# In[9]:


dataset['Life expectancy '].fillna((dataset['Life expectancy '].mean()),inplace=True) #inplace :is used to reflect in the data set


# In[10]:


dataset['Adult Mortality'].fillna((dataset['Adult Mortality'].mean()),inplace=True) #inplace :is used to reflect in the data set


# In[11]:


dataset['Alcohol'].fillna((dataset['Alcohol'].mean()),inplace=True) #inplace :is used to reflect in the data set


# In[12]:


dataset['Hepatitis B'].fillna((dataset['Hepatitis B'].mean()),inplace=True) #inplace :is used to reflect in the data set


# In[13]:


dataset[' BMI '].fillna((dataset[' BMI '].mean()),inplace=True) #inplace :is used to reflect in the data set


# In[14]:


dataset['Polio'].fillna((dataset['Polio'].mean()),inplace=True) #inplace :is used to reflect in the data set


# In[15]:


dataset['Total expenditure'].fillna((dataset['Total expenditure'].mean()),inplace=True) #inplace :is used to reflect in the data set


# In[16]:


dataset['Diphtheria '].fillna((dataset['Diphtheria '].mean()),inplace=True) #inplace :is used to reflect in the data set


# In[17]:


dataset['GDP'].fillna((dataset['GDP'].mean()),inplace=True) #inplace :is used to reflect in the data set


# In[18]:


dataset['Population'].fillna((dataset['Population'].mean()),inplace=True) #inplace :is used to reflect in the data set


# In[19]:


dataset[' thinness  1-19 years'].fillna((dataset[' thinness  1-19 years'].mean()),inplace=True) #inplace :is used to reflect in the data set


# In[20]:


dataset[' thinness 5-9 years'].fillna((dataset[' thinness 5-9 years'].mean()),inplace=True) #inplace :is used to reflect in the data set


# In[21]:


dataset['Income composition of resources'].fillna((dataset['Income composition of resources'].mean()),inplace=True) #inplace :is used to reflect in the data set


# In[22]:


dataset['Schooling'].fillna((dataset['Schooling'].mean()),inplace=True) #inplace :is used to reflect in the data set


# In[23]:


dataset.isnull().any()


# In[24]:


dataset


# In[25]:


y=dataset.iloc[:,:1].values
y


# In[26]:


x=dataset.iloc[:,1:].values
x


# In[27]:


x


# In[28]:


x.shape


# In[29]:


y.shape


# In[30]:


from sklearn.model_selection import train_test_split


# In[31]:


x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=0)


# In[32]:


x_test


# In[33]:


x_train


# # Multi Linear Regression

# In[34]:


from sklearn.linear_model import LinearRegression


# In[35]:


mr=LinearRegression()


# In[36]:


mr.fit(x_train,y_train)# training process


# In[37]:


x_test


# In[38]:


y_predict_mr=mr.predict(x_test)
y_predict_mr


# In[39]:


mr.predict([[263.0,62,0.010000,71.279624,65.000000,1154,19.1,83,6.0,8.16000,65.0,0.1,584.259210,33736494.0,17.2,17.3,0.479,10.1]])


# In[40]:


x_test.shape


# In[41]:


x_train.shape


# In[42]:


mr.score(x_train,y_train)


# In[43]:


plt.scatter(x_train[:,6],y_train)


# In[44]:


plt.scatter(x_train[:,3],y_train)


# In[45]:


from sklearn.metrics import r2_score


# In[46]:


r2_score(y_test,y_predict_mr)


# # polynomial linear regression

# In[47]:


from sklearn.preprocessing import PolynomialFeatures
poly_reg = PolynomialFeatures(degree=2)
X_poly =poly_reg.fit_transform(x)
X_poly


# In[48]:


pr=LinearRegression()


# In[49]:


pr.fit(X_poly,y)# training process


# In[50]:


X_poly


# In[51]:


pr.predict(X_poly)


# In[52]:


y_predict=pr.predict(poly_reg.fit_transform(x))


# In[53]:


y_predict


# In[54]:


from sklearn.metrics import r2_score


# In[55]:


r2_score(y,y_predict)


# # Decision Tree

# In[56]:


from sklearn.tree import DecisionTreeRegressor
regressor= DecisionTreeRegressor(random_state=0)
regressor.fit(x_train,y_train)


# In[57]:


y_predict_dt =regressor.predict(x_test)


# In[58]:


y_predict_dt


# In[59]:


regressor.predict([[263.0,62,0.010000,71.279624,65.000000,1154,19.1,83,6.0,8.16000,65.0,0.1,584.259210,33736494.0,17.2,17.3,0.479,10.1]])


# In[60]:


from sklearn.metrics import r2_score
r2_score(y_test,y_predict_dt)


# # Random Forest

# In[61]:


from sklearn.ensemble import RandomForestRegressor
random = RandomForestRegressor(n_estimators=10,criterion='mse',random_state=0)


# In[62]:


random.fit(x_train,y_train)


# In[63]:


y_predict_rf = random.predict(x_test)
y_predict_rf


# In[64]:


from sklearn.metrics import r2_score
r2_score(y_test,y_predict_rf)


# In[65]:


random.predict([[263.0,62,0.010000,71.279624,65.000000,1154,19.1,83,6.0,8.16000,65.0,0.1,584.259210,33736494.0,17.2,17.3,0.479,10.1]])

